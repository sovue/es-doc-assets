ЗАГЛУШКА: map.zip

Оригинальный материал ещё не перенесён с YoNote.
Этот файл нужно заменить правильным материалом.
Статья: /docs/code_examples
Раздел: Создание собственной карты
Старое вложение: attachment:/api/attachments.redirect?id=aabcba4d-80bd-4a78-af19-b222ecd775ab

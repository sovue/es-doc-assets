init:
    $ mods["bruhlul"] = "КАРТА"

label bruhlul:
    $ init_map_zones_mymod()

    $ disable_all_zones_mymod()

    $ set_zone_mymod("house_1", "label_of_house")

    $ show_map_mymod()

label label_of_house:
    "Домик #1"